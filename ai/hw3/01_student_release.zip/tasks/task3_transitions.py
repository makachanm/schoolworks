from typing import List, Tuple
from core.config import Action
from core.base_mdp import State
from core.utils import is_dirt_dirty, set_dirt_clean

def get_transitions(self, state: State, action: Action) -> List[Tuple[float, State, float, str]]:
    """
    [Task 3] 전이 확률(Transition Model) 구현
    주어진 상태에서 행동을 취했을 때 가능한 모든 다음 상태와 그 확률 반환.
    각 요소는 (확률, 다음 상태, 보상, 이벤트 설명) 튜플입니다.

    구현 순서 제안:
    1. terminal state라면 빈 리스트 반환
    2. action 종류별 base outcome 생성
       - 이동: self.move_dist_table 사용
       - CLEAN: 먼지가 있으면 청소, 없으면 빈 바닥 청소
       - CHARGE: 충전소면 충전, 아니면 invalid charge
    3. CLEAN / 이동 결과 뒤에 redirt 확률 결합
    4. next_battery, next_state, reward 계산

    HINT:
    - 이동 확률은 부모 클래스의 self.move_dist_table
    - 재오염 확률은 self.redirt_table
    """
    raise NotImplementedError("TODO: Implement transition model.")
