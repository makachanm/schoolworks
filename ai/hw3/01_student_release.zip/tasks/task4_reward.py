from typing import Tuple
from core.config import Action
from core.base_mdp import State
from core.utils import is_dirt_dirty, set_dirt_clean

def compute_reward_internal(self, state: State, action: Action, next_pos: Tuple[int, int], next_mask: int, next_battery: int, event: str) -> float:
    """
    [Task 4] 보상(Reward) 체계 구현
    특정 행동과 그에 따른 다음 상태에 대해 보상을 계산하여 반환.

    생각할 보상 항목:
    - 기본 이동 비용
    - 벽 충돌 / 고양이 간섭 페널티
    - 젖은 바닥 진입 페널티
    - 청소 성공 / 빈 바닥 청소 / 충전 실패
    - 배터리 방전
    - 모든 먼지 청소 완료 보너스
    - 목표 지점 복귀 보너스

    event 문자열과 next_state 정보를 함께 사용하면 분기하기 편합니다.
    """
    raise NotImplementedError("TODO: Implement reward computation.")
