/*
 * File Name    : subc.y
 * Description  : a skeleton bison input
 * 
 * Course       : Compiler
 */

%{
/* Prologue section */
#include <stdio.h>
#include <strings.h>

int   yylex ();
int   yyerror (char* s);
void  reduce(char* s);
%}

/* Tokens */
%token TYPE STRUCT SYM_NULL RETURN IF ELSE WHILE FOR BREAK CONTINUE
%token INTEGER_CONST CHAR_CONST STRING ID
%token LOGICAL_OR LOGICAL_AND RELOP EQUOP INCOP DECOP STRUCTOP

/* Bison declarations section */
/* Precedences and Associativities */
%left ','
%right '='
%left LOGICAL_OR
%left LOGICAL_AND
%left EQUOP
%left RELOP
%left '+' '-'
%left '*' '/' '%'
%right '!' UNARY 
%left '(' '[' '.' STRUCTOP INCOP DECOP

%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE
%%

/* Grammar rules section*/
program
  : ext_def_list
  { reduce("program->ext_def_list"); }
  ;

ext_def_list
  : ext_def_list ext_def
  { reduce("ext_def_list->ext_def_list ext_def"); }
  | /* empty */
  { reduce("ext_def_list->epsilon"); }
  ;

ext_def
  : type_specifier pointers ID ';'
  { reduce("ext_def->type_specifier pointers ID ';'"); }
  | type_specifier pointers ID '[' INTEGER_CONST ']' ';'
  { reduce("ext_def->type_specifier pointers ID '[' INTEGER_CONST ']' ';'"); }
  | STRUCT ID '{' def_list '}' ';'
  { reduce("ext_def->STRUCT ID '{' def_list '}' ';'"); }
  | func_decl compound_stmt
  { reduce("ext_def->func_decl compound_stmt"); }
  ;

type_specifier
  : TYPE
  { reduce("type_specifier->TYPE"); }
  | struct_specifier
  { reduce("type_specifier->struct_specifier"); }
  ;

struct_specifier
  : STRUCT ID '{' def_list '}'
  { reduce("struct_specifier->STRUCT ID '{' def_list '}'"); }
  | STRUCT ID
  { reduce("struct_specifier->STRUCT ID"); }
  ;

func_decl
  : type_specifier pointers ID '(' ')'
  { reduce("func_decl->type_specifier pointers ID '(' ')'"); }
  | type_specifier pointers ID '(' param_list ')'
  { reduce("func_decl->type_specifier pointers ID '(' param_list ')'"); }
  ;

pointers
  : '*'
  { reduce("pointers->'*'"); }
  | /* empty */
  { reduce("pointers->epsilon"); }
  ;

param_list
  : param_decl
  { reduce("param_list->param_decl"); }
  | param_list ',' param_decl
  { reduce("param_list->param_list ',' param_decl"); }
  ;

param_decl
  : type_specifier pointers ID
  { reduce("param_decl->type_specifier pointers ID"); }
  | type_specifier pointers ID '[' INTEGER_CONST ']'
  { reduce("param_decl->type_specifier pointers ID '[' INTEGER_CONST ']'"); }
  ;

def_list
  : def_list def
  { reduce("def_list->def_list def"); }
  | /* empty */
  { reduce("def_list->epsilon"); }
  ;

def
  : type_specifier pointers ID ';'
  { reduce("def->type_specifier pointers ID ';'"); }
  | type_specifier pointers ID '[' INTEGER_CONST ']' ';'
  { reduce("def->type_specifier pointers ID '[' INTEGER_CONST ']' ';'"); }
  ;

compound_stmt
  : '{' def_list stmt_list '}'
  { reduce("compound_stmt->'{' def_list stmt_list '}'"); }
  ;

stmt_list
  : stmt_list stmt
  { reduce("stmt_list->stmt_list stmt"); }
  | /* empty */
  { reduce("stmt_list->epsilon"); }
  ;

stmt
  : expr ';'
  { reduce("stmt->expr ';'"); }
  | compound_stmt
  { reduce("stmt->compound_stmt"); }
  | RETURN expr ';'
  { reduce("stmt->RETURN expr ';'"); }
  | ';'
  { reduce("stmt->';'"); }
  | IF '(' expr ')' stmt %prec LOWER_THAN_ELSE
  { reduce("stmt->IF '(' expr ')' stmt"); }
  | IF '(' expr ')' stmt ELSE stmt
  { reduce("stmt->IF '(' expr ')' stmt ELSE stmt"); }
  | WHILE '(' expr ')' stmt
  { reduce("stmt->WHILE '(' expr ')' stmt"); }
  | FOR '(' expr_e ';' expr_e ';' expr_e ')' stmt
  { reduce("stmt->FOR '(' expr_e ';' expr_e ';' expr_e ')' stmt"); }
  | BREAK ';'
  { reduce("stmt->BREAK ';'"); }
  | CONTINUE ';'
  { reduce("stmt->CONTINUE ';'"); }
  ;

expr_e
  : expr
  { reduce("expr_e->expr"); }
  | /* empty */
  { reduce("expr_e->epsilon"); }
  ;

expr
  : unary '=' expr
  { reduce("expr->unary '=' expr"); }
  | binary
  { reduce("expr->binary"); }
  ;

binary
  : unary
  { reduce("binary->unary"); }
  | binary '*' binary
  { reduce("binary->binary '*' binary"); }
  | binary '/' binary
  { reduce("binary->binary '/' binary"); }
  | binary '%' binary
  { reduce("binary->binary '%' binary"); }
  | binary '+' binary
  { reduce("binary->binary '+' binary"); }
  | binary '-' binary
  { reduce("binary->binary '-' binary"); }
  | binary RELOP binary
  { reduce("binary->binary RELOP binary"); }
  | binary EQUOP binary
  { reduce("binary->binary EQUOP binary"); }
  | binary LOGICAL_AND binary
  { reduce("binary->binary LOGICAL_AND binary"); }
  | binary LOGICAL_OR binary
  { reduce("binary->binary LOGICAL_OR binary"); }
  ;

unary
  : INTEGER_CONST
  { reduce("unary->INTEGER_CONST"); }
  | CHAR_CONST
  { reduce("unary->CHAR_CONST"); }
  | STRING
  { reduce("unary->STRING"); }
  | ID
  { reduce("unary->ID"); }
  | '-' unary %prec UNARY
  { reduce("unary->'-' unary"); }
  | '!' unary %prec UNARY
  { reduce("unary->'!' unary"); }
  | unary INCOP
  { reduce("unary->unary INCOP"); }
  | unary DECOP
  { reduce("unary->unary DECOP"); }
  | INCOP unary
  { reduce("unary->INCOP unary"); }
  | DECOP unary
  { reduce("unary->DECOP unary"); }
  | '&' unary %prec UNARY
  { reduce("unary->'&' unary"); }
  | '*' unary %prec UNARY
  { reduce("unary->'*' unary"); }
  | unary '[' expr ']'
  { reduce("unary->unary '[' expr ']'"); }
  | unary '.' ID
  { reduce("unary->unary '.' ID"); }
  | unary STRUCTOP ID
  { reduce("unary->unary STRUCTOP ID"); }
  | unary '(' args ')'
  { reduce("unary->unary '(' args ')'"); }
  | unary '(' ')'
  { reduce("unary->unary '(' ')'"); }
  | '(' expr ')'
  { reduce("unary->'(' expr ')'"); }
  | SYM_NULL
  { reduce("unary->SYM_NULL"); }
  ;

args
  : expr
  { reduce("args->expr"); }
  | args ',' expr
  { reduce("args->args ',' expr"); }
  ;
%%

/* Epilogue section */

int yyerror (char* s) {
  fprintf (stderr, "yyerror: %s\n", s);
}

void reduce(char* s) {
  printf("%s\n", s);
}

int main(int argc, char* argv[]) {
    if (argc >= 2) {
        extern FILE* yyin;
        yyin = fopen(argv[1], "r");
        if (!yyin) {
            perror("fopen");
            return 1;
        }
    }

    return yyparse();
}
